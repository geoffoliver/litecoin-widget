Litecoin price widget
====================

Retrieves Litecoin exchange rate prices for currencies from coinmarketcap.com

Works with [Übersicht](http://tracesof.net/uebersicht/) on OSX.

Built off of http://tracesof.net/uebersicht-widgets/#btc-prices