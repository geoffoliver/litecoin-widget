Bitcoin price widget
====================

Retrieves Bitcoin exchange rate prices for currencies from blockchain.info's
public API.

Works with [Übersicht](http://tracesof.net/uebersicht/) on OSX.

Modifying
---------
To change which currencies are displayed, modify this line:

```javascript
  CURRENCIES = ["AUD", "USD"]
```
